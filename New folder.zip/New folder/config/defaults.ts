export default {
 portNumber: 5000,
 host: 'localhost',
 dbUrl: "mongodb://localhost:27017/dingi",
 dbConfig: {
  useNewUrlParser: true, useUnifiedTopology: true
 },
 clientID: "76842428542-9s2nnl0vth3qkfp6hgf9tddhda5scuok.apps.googleusercontent.com",
  clientSecret: "udmPKX_iehEdrW0AIHEd2yWd",
 botPolling: true,
};