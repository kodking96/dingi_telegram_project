import routes from './routes'

export default routes