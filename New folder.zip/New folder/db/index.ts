import dbConnect from "./dbConnect"

export default dbConnect